/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bao.w.DTO;

public class Escritor {
    	public String nome;
	public String sexo;
	public int id_esc;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	
	public int getId_esc() {
		return id_esc;
	}
	public void setId_esc(int id_esc) {
		this.id_esc = id_esc;
	}
}
